package Restaurante;

import java.util.ArrayList;
import java.util.List;

public class Cliente extends Persona {
	
	private String direccion;
	
	private List<Pedido> pedidos;
	
	public Cliente(String nombre, int telefono, String direccion) {
		
		super (nombre, telefono);
		this.direccion = direccion;
		this.pedidos = new ArrayList<>();
		
	}
	
	public boolean hacerReserva(Mesa mesa) {
		
		return mesa.reservar();
		
	}
	
	public void agregarPedido(Pedido pedido) {
		
		pedidos.add(pedido);
		
	}
	
	public List<Pedido> getPedidos() {
		
		return pedidos;
		
	}

}
