package Restaurante;

public class Categoria {
	
	private String nombre;
	private String descripcionP;
	
	public Categoria(String nombre, String descripcionP) {
		
		this.nombre = nombre;
		this.descripcionP = descripcionP;
		
	}
	
	public String getNombre() {
		
		return nombre;
		
	}
	
	public String getDescripcionP() {
		
		return descripcionP;
		
	}

}
