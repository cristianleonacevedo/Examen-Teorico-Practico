package Restaurante;

import java.util.ArrayList;
import java.util.List;

public class Mesa {

	private int numero;
	private int capacidad;
	private boolean reservada;
	private Empleado empleadoAsignado;
	private List<Pedido> pedidos;
	
	public Mesa(int numero, int capacidad) {
		
		this.numero = numero;
		this.capacidad = 4;
		this.reservada = false;
		this.pedidos = new ArrayList<>();
		
	}
	
	public boolean reservar() {
		
		if (!reservada) {
			
			reservada = true;
			return true;
			
		} else {
			
			return false;
			
		}
			
	}
		
		public void agregarPedido(Pedido pedido) {
			
			pedidos.add(pedido);
			
		}
		
		public void cerrarMesa() {
			
			pedidos.clear();
			
			reservada = false;
			
		}
		
		public void setEmpleadoAsignado(Empleado empleado) {
			
			this.empleadoAsignado = empleado;
			
		}
		
	}

	

