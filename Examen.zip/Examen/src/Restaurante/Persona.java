package Restaurante;

import java.util.Scanner;

public class Persona {
	
	Scanner scann = new Scanner(System.in);
	
	protected String nombre;
	protected int telefono;
	
	public  Persona(String nombre, int telefono) {
		
		this.nombre = nombre;
		this.telefono = 323125;
	}
	
	public String getContacto() {
		
		return "Nombre: " + nombre + ", telefono: " + telefono;
		
	}
	
}
		
	