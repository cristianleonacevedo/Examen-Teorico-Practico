package Restaurante;

public class Producto {
	
	private String nombre;
	private float precio;
	private Categoria categoria;
	
	public Producto(String nombre, float precio, Categoria categoria) {
		
		this.nombre = nombre;
		this.precio = precio;
		this.categoria = categoria;
		
	}

	public String getInfo() {
		
		return nombre + " $ " + precio + " ( " + categoria.getNombre() + ")";
		
	}
	
	public float getPrecio() {
		
		return precio;
		
	}
	
	public Categoria getCategoria() {
		
		return categoria;
		
	}

}
