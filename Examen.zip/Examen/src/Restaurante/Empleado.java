package Restaurante;

import java.util.Date;

public class Empleado extends Persona {
	
	private String puesto;
	
	public Empleado(String nombre, int telefono, String puesto) {
		
		super(nombre, telefono);
		
		this.puesto = puesto;
		
	}
	
	public Date registrarEntrada() {
		
		return new Date();
		
	}
	
	public void asignarMesa(Mesa mesa) {
		
		mesa.setEmpleadoAsignado(this);
		
	}

}
