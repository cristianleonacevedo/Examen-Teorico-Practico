package Restaurante;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;

public class Pedido {

	private Date fechaHora;
	private String estado;
	private List<Producto> productos;
	
	public Pedido() {
		
		this.fechaHora = new Date();
		this.estado = "pendiente";
		this.productos = new ArrayList<>();
		
	}
	
	public void agregarProducto(Producto producto) {
		
		productos.add(producto);
		
	}
	
	public double calcularTotal() {
		
		double total = 0;
		
		for (Producto p : productos) {
			
			total += p.getPrecio();
			
		}
		
		return total;
	
	}
		
		public void setEstado(String estado) {
			
			this.estado = estado;
			
		}
		
	}
	

